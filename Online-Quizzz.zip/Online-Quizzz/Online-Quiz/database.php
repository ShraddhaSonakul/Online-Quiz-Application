<?php
$con= new mysqli('Localhost:3009','root','','exam')or die("Could not connect to mysql".mysqli_error($con));
?>